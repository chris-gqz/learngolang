[TOC]

## 一、课前准备

> 掌握了一些常规数据库的操作，比如数据库的增删改查等等



## 二、课堂主题

> 说明：



## 三、课堂目标

> 说明：完成本章课程案例



## 四、知识点

> 



### 1. 访问数据库（50分钟）



对许多Web应用程序而言，数据库都是其核心所在。数据库几乎可以用来存储你想查询和修改的任何信息，比如用户信息、产品目录或者新闻列表等。

Go没有内置的驱动支持任何的数据库，但是Go定义了database/sql接口，用户可以基于驱动接口开发相应数据库的驱动。对于开发而言，以下内容需要了解掌握，使用的时候可以对照文档进行编写即可。

#### 1.1 sql.Register

这个存在于`database/sql`的函数是用来注册数据库驱动的，当第三方开发者开发数据库驱动时，都会实现init函数，在init里面会调用这个`Register(name string, driver driver.Driver)`完成本驱动的注册。

`import _ "github.com/go-sql-driver/mysql"`前面的”_”作用时不需要把该包都导进来，只执行包的init()方法，mysql驱动正是通过这种方式注册到”database/sql”中的：

```go
//github.com/go-sql-driver/mysql/driver.go
func init() {
    sql.Register("mysql", &MySQLDriver{})
}

type MySQLDriver struct{}

func (d MySQLDriver) Open(dsn string) (driver.Conn, error) {
    ...
}
```

`init()`通过`Register()`方法将mysql驱动添加到sql.drivers。第三方数据库驱动都是通过调用这个函数来注册自己的数据库驱动名称以及相应的driver实现。在database/sql内部通过一个map来存储用户定义的相应驱动。

```go
var drivers = make(map[string]driver.Driver)
```

假如我们同时用到多种数据库，就可以通过调用`sql.Register`将不同数据库的实现注册到`sql.drivers`中去，用的时候再根据注册的name将对应的driver取出。因此通过database/sql的注册函数可以同时注册多个数据库驱动，只要不重复。

```go
//database/sql/sql.go
func Register(name string, driver driver.Driver) {
    driversMu.Lock()
    defer driversMu.Unlock()
    if driver == nil {
        panic("sql: Register driver is nil")
    }
    if _, dup := drivers[name]; dup {
        panic("sql: Register called twice for driver " + name)
    }
    drivers[name] = driver
}
```

其中init函数的初始化过程，包在引入的时候会自动调用包的init函数以完成对包的初始化。因此，引入上面的数据库驱动包之后要手动去调用init函数，然后在init函数里面注册这个数据库驱动，这样就可以在接下来的代码中直接使用这个数据库驱动了。

#### 1.2 driver.Driver

`init()`通过`Register()`方法将mysql驱动添加到sql.drivers(类型：`make(map[string]driver.Driver)`)中，MySQLDriver实现了driver.Driver接口。

Driver是一个数据库驱动的接口，他定义了一个method： Open(name string)，这个方法返回一个数据库的Conn接口。

```go
//database/sql/driver/driver.go
type Driver interface {
    // Open returns a new connection to the database.
    // The name is a string in a driver-specific format.
    //
    // Open may return a cached connection (one previously
    // closed), but doing so is unnecessary; the sql package
    // maintains a pool of idle connections for efficient re-use.
    //
    // The returned connection is only used by one goroutine at a
    // time.
    Open(name string) (Conn, error)
}
```

返回的Conn只能用来进行一次goroutine的操作，也就是说不能把这个Conn应用于Go的多个goroutine里面。如下代码会出现错误

```go
...

go goroutineA (Conn) //执行查询操作

go goroutineB (Conn) //执行插入操作

...
```

上面这样的代码可能会使Go不知道某个操作究竟是由哪个goroutine发起的,从而导致数据混乱，比如可能会把

goroutineA里面执行的查询操作的结果返回给goroutineB从而使B错误地把此结果当成自己执行的插入数据。

第三方驱动都会定义这个函数，它会解析name参数来获取相关数据库的连接信息，解析完成后，它将使用此信息来初始化一个Conn并返回它。

#### 1.3 driver.Conn

Conn是一个数据库连接的接口定义，他定义了一系列方法，这个Conn只能应用在一个goroutine里面，不能使用在多个goroutine里面，详情请参考上面的说明。

```go
type Conn interface {

    Prepare(query string) (Stmt, error)

    Close() error

    Begin() (Tx, error)

}
```

- Prepare函数返回与当前连接相关的执行Sql语句的准备状态，可以进行查询、删除等操作。
- Close函数关闭当前的连接，执行释放连接拥有的资源等清理工作。因为驱动实现了database/sql里面建议的conn pool，所以你不用再去实现缓存conn之类的，这样会容易引起问题。
- Begin函数返回一个代表事务处理的Tx，通过它你可以进行查询,更新等操作，或者对事务进行回滚、递交。

#### 1.4 driver.Stmt

Stmt是一种准备好的状态，和Conn相关联，而且只能应用于一个goroutine中，不能应用于多个goroutine。

```go
type Stmt interface {

    Close() error

    NumInput() int

    Exec(args []Value) (Result, error)

    Query(args []Value) (Rows, error)

}
```

- Close函数关闭当前的链接状态，但是如果当前正在执行query，query还是有效返回rows数据。
- NumInput函数返回当前预留参数的个数，当返回>=0时数据库驱动就会智能检查调用者的参数。当数据库驱动包不知道预留参数的时候，返回-1。
- Exec函数执行Prepare准备好的sql，传入参数执行update/insert等操作，返回Result数据。
- Query函数执行Prepare准备好的sql，传入需要的参数执行select操作，返回Rows结果集。

#### 1.5 driver.Tx

事务处理一般就两个过程，递交或者回滚。数据库驱动里面也只需要实现这两个函数就可以。

```go
type Tx interface {

    Commit() error

    Rollback() error

}
```

这两个函数一个用来递交一个事务，一个用来回滚事务。

#### 1.6 driver.Execer

这是一个Conn可选择实现的接口。

```go
type Execer interface {

    Exec(query string, args []Value) (Result, error)

}
```

如果这个接口没有定义，那么在调用DB.Exec,就会首先调用Prepare返回Stmt，然后执行Stmt的Exec，然后关闭

Stmt。

#### 1.7 driver.Result

这个是执行Update/Insert等操作返回的结果接口定义。

```go
type Result interface {

    LastInsertId() (int64, error)

    RowsAffected() (int64, error)

}
```

- `LastInsertId`函数返回由数据库执行插入操作得到的自增ID号。
- `RowsAffected`函数返回query操作影响的数据条目数。

#### 1.8 driver.Rows

Rows是执行查询返回的结果集接口定义

```go
type Rows interface {

    Columns() []string

    Close() error

    Next(dest []Value) error

}
```

- Columns函数返回查询数据库表的字段信息，这个返回的slice和sql查询的字段一一对应，而不是返回整个表的所有字段。
- Close函数用来关闭Rows迭代器。
- Next函数用来返回下一条数据，把数据赋值给dest。dest里面的元素必须是driver.Value的值除了string，返回的数据里面所有的string都必须要转换成[]byte。如果最后没数据了，Next函数最后返回io.EOF。

#### 1.9 driver.RowsAffected

RowsAffested其实就是一个int64的别名，但是他实现了Result接口，用来底层实现Result的表示方式

```go
type RowsAffected int64

func (RowsAffected) LastInsertId() (int64, error)

func (v RowsAffected) RowsAffected() (int64, error)
```

#### 1.10 driver.Value

Value其实就是一个空接口，他可以容纳任何的数据。

```go
type Value interface{}
```

drive的Value是驱动必须能够操作的Value，Value要么是nil，要么是下面的任意一种

```go
int64

float64

bool

[]byte

string [*]除了Rows.Next返回的不能是string.

time.Time
```

#### 1.11 driver.ValueConverter

ValueConverter接口定义了如何把一个普通的值转化成driver.Value的接口

```go
type ValueConverter interface {

    ConvertValue(v interface{}) (Value, error)

}
```

在开发的数据库驱动包里面实现这个接口的函数在很多地方会使用到，这个ValueConverter有很多好处：

1. 转化`driver.value`到数据库表相应的字段，例如int64的数据如何转化成数据库表uint16字段
2. 把数据库查询结果转化成`driver.Value`值
3. 在scan函数里面如何把`driver.Value`值转化成用户定义的值

#### 1.12 driver.Valuer

Valuer接口定义了返回一个`driver.Value`的方式

```go
type Valuer interface {

    Value() (Value, error)

}
```

很多类型都实现了这个Value方法，用来自身与`driver.Value`的转化。

通过上面的讲解，你应该对于驱动的开发有了一个基本的了解，一个驱动只要实现了这些接口就能完成增删查改等基本操作了，剩下的就是与相应的数据库进行数据交互等细节问题了，在此不再赘述。

#### 1.13 database/sql

database/sql在database/sql/driver提供的接口基础上定义了一些更高阶的方法，用以简化数据库操作,同时内部还建议性地实现一个conn pool。

```go
type DB struct {
    driver driver.Driver  //数据库实现驱动
    dsn    string  //数据库连接、配置参数信息，比如username、host、password等
    numClosed uint64

    mu           sync.Mutex          //锁，操作DB各成员时用到
    freeConn     []*driverConn       //空闲连接
    connRequests []chan connRequest  //阻塞请求队列，等连接数达到最大限制时，后续请求将插入此队列等待可用连接
    numOpen      int                 //已建立连接或等待建立连接数
    openerCh    chan struct{}        //用于connectionOpener
    closed      bool
    dep         map[finalCloser]depSet
    lastPut     map[*driverConn]string // stacktrace of last conn's put; debug only
    maxIdle     int                    //最大空闲连接数
    maxOpen     int                    //数据库最大连接数
    maxLifetime time.Duration          //连接最长存活期，超过这个时间连接将不再被复用
    cleanerCh   chan struct{}
}
```

> `maxIdle`(默认值2)、`maxOpen`(默认值0，无限制)、`maxLifetime(默认值0，永不过期)`可以分别通过`SetMaxIdleConns`、`SetMaxOpenConns`、`SetConnMaxLifetime`设定。

我们可以看到Open函数返回的是DB对象，里面有一个freeConn，它就是那个简易的连接池。它的实现相当简单或者说简陋，就是当执行Db.prepare的时候会`defer db.putConn(ci, err)`，也就是把这个连接放入连接池，每次调用conn的时候会先判断freeConn的长度是否大于0，大于0说明有可以复用的conn，直接拿出来用就是了，如果不大于0，则创建一个conn,然后再返回之。

> 这时mysql还没有建立连接，只是初始化了一个`sql.DB`结构，这是非常重要的一个结构，所有相关的数据都保存在此结构中；Open同时启动了一个`connectionOpener`协程。

#### 1.14 获取连接

上面说了Open时是没有建立数据库连接的，只有等用的时候才会实际建立连接，获取可用连接的操作有两种策略：cachedOrNewConn(有可用空闲连接则优先使用，没有则创建)、alwaysNewConn(不管有没有空闲连接都重新创建)，下面以一个query的例子看下具体的操作：

```go
rows, err := db.Query("select * from userinfo")
```

以下是Query的源代码：

```go
//database/sql/sql.go：
func (db *DB) Query(query string, args ...interface{}) (*Rows, error) {
    var rows *Rows
    var err error
    //maxBadConnRetries = 2
    for i := 0; i < maxBadConnRetries; i++ {
        rows, err = db.query(query, args, cachedOrNewConn)
        if err != driver.ErrBadConn {
            break
        }
    }
    if err == driver.ErrBadConn {
        return db.query(query, args, alwaysNewConn)
    }
    return rows, err
}

func (db *DB) query(query string, args []interface{}, strategy connReuseStrategy) (*Rows, error) {
    ci, err := db.conn(strategy)
    if err != nil {
        return nil, err
    }

    //到这已经获取到了可用连接，下面进行具体的数据库操作
    return db.queryConn(ci, ci.releaseConn, query, args)
}
```

数据库连接由`db.query()`获取：

```go
func (db *DB) conn(strategy connReuseStrategy) (*driverConn, error) {
    db.mu.Lock()
    if db.closed {
        db.mu.Unlock()
        return nil, errDBClosed
    }
    lifetime := db.maxLifetime

    //从freeConn取一个空闲连接
    numFree := len(db.freeConn)
    if strategy == cachedOrNewConn && numFree > 0 {
        conn := db.freeConn[0]
        copy(db.freeConn, db.freeConn[1:])
        db.freeConn = db.freeConn[:numFree-1]
        conn.inUse = true
        db.mu.Unlock()
        if conn.expired(lifetime) {
            conn.Close()
            return nil, driver.ErrBadConn
        }
        return conn, nil
    }

    //如果没有空闲连接，而且当前建立的连接数已经达到最大限制则将请求加入connRequests队列，
    //并阻塞在这里，直到其它协程将占用的连接释放或connectionOpenner创建
    if db.maxOpen > 0 && db.numOpen >= db.maxOpen {
        // Make the connRequest channel. It's buffered so that the
        // connectionOpener doesn't block while waiting for the req to be read.
        req := make(chan connRequest, 1)
        db.connRequests = append(db.connRequests, req)
        db.mu.Unlock()
        ret, ok := <-req  //阻塞
        if !ok {
            return nil, errDBClosed
        }
        if ret.err == nil && ret.conn.expired(lifetime) { //连接过期了
            ret.conn.Close()
            return nil, driver.ErrBadConn
        }
        return ret.conn, ret.err
    }

    db.numOpen++ //上面说了numOpen是已经建立或即将建立连接数，这里还没有建立连接，只是乐观的认为后面会成功，失败的时候再将此值减1
    db.mu.Unlock()
    ci, err := db.driver.Open(db.dsn) //调用driver的Open方法建立连接
    if err != nil { //创建连接失败
        db.mu.Lock()
        db.numOpen-- // correct for earlier optimism
        db.maybeOpenNewConnections()  //通知connectionOpener协程尝试重新建立连接，否则在db.connRequests中等待的请求将一直阻塞，知道下次有连接建立
        db.mu.Unlock()
        return nil, err
    }
    db.mu.Lock()
    dc := &driverConn{
        db:        db,
        createdAt: nowFunc(),
        ci:        ci,
    }
    db.addDepLocked(dc, dc)
    dc.inUse = true
    db.mu.Unlock()
    return dc, nil
}
```

总结一下上面获取连接的过程： 

- step1：首先检查下freeConn里是否有空闲连接，如果有且未超时则直接复用，返回连接，如果没有或连接已经过期则进入下一步； 
- step2：检查当前已经建立及准备建立的连接数是否已经达到最大值，如果达到最大值也就意味着无法再创建新的连接了，当前请求需要在这等着连接释放，这时当前协程将创建一个channel：chan connRequest，并将其插入db.connRequests队列，然后阻塞在接收chan connRequest上，等到有连接可用时这里将拿到释放的连接，检查可用后返回；如果还未达到最大值则进入下一步； 
- step3：创建一个连接，首先将numOpen加1，然后再创建连接，如果等到创建完连接再把numOpen加1会导致多个协程同时创建连接时一部分会浪费，所以提前将numOpen占住，创建失败再将其减掉；如果创建连接成功则返回连接，失败则进入下一步 
- step4：创建连接失败时有一个善后操作，当然并不仅仅是将最初占用的numOpen数减掉，更重要的一个操作是通知connectionOpener协程根据db.connRequests等待的长度创建连接，这个操作的原因是：numOpen在连接成功创建前就加了1，这时候如果numOpen已经达到最大值再有获取conn的请求将阻塞在step2，这些请求会等着先前进来的请求释放连接，假设先前进来的这些请求创建连接全部失败，那么如果它们直接返回了那些等待的请求将一直阻塞在那，因为不可能有连接释放(极限值，如果部分创建成功则会有部分释放)，直到新请求进来重新成功创建连接，显然这样是有问题的，所以maybeOpenNewConnections将通知connectionOpener根据db.connRequests长度及可创建的最大连接数重新创建连接，然后将新创建的连接发给阻塞的请求。

注意：如果maxOpen=0将不会有请求阻塞等待连接，所有请求只要从freeConn中取不到连接就会新创建。

另外Query、Exec有个重试机制，首先优先使用空闲连接，如果2次取到的连接都无效则尝试新创建连接。

获取到可用连接后将调用具体数据库的driver处理sql。

#### 1.15 释放连接

数据库连接在被使用完成后需要归还给连接池以供其它请求复用，释放连接的操作是：`putConn()`：

```go
func (db *DB) putConn(dc *driverConn, err error) {
    ...

    //如果连接已经无效，则不再放入连接池
    if err == driver.ErrBadConn {
        db.maybeOpenNewConnections()
        dc.Close() //这里最终将numOpen数减掉
        return
    }
    ...

    //正常归还
    added := db.putConnDBLocked(dc, nil)
    ...
}

func (db *DB) putConnDBLocked(dc *driverConn, err error) bool {
    if db.maxOpen > 0 && db.numOpen > db.maxOpen {
        return false
    }
    //有等待连接的请求则将连接发给它们，否则放入freeConn
    if c := len(db.connRequests); c > 0 {
        req := db.connRequests[0]
        // This copy is O(n) but in practice faster than a linked list.
        // TODO: consider compacting it down less often and
        // moving the base instead?
        copy(db.connRequests, db.connRequests[1:])
        db.connRequests = db.connRequests[:c-1]
        if err == nil {
            dc.inUse = true
        }
        req <- connRequest{
            conn: dc,
            err:  err,
        }
        return true
    } else if err == nil && !db.closed && db.maxIdleConnsLocked() > len(db.freeConn) {
        db.freeConn = append(db.freeConn, dc)
        db.startCleanerLocked()
        return true
    }
    return false
}
```

释放的过程： 

- step1：首先检查下当前归还的连接在使用过程中是否发现已经无效，如果无效则不再放入连接池，然后检查下等待连接的请求数新建连接，类似获取连接时的异常处理，如果连接有效则进入下一步； 
- step2：检查下当前是否有等待连接阻塞的请求，有的话将当前连接发给最早的那个请求，没有的话则再判断空闲连接数是否达到上限，没有则放入freeConn空闲连接池，达到上限则将连接关闭释放。 
- step3：(只执行一次)启动connectionCleaner协程定时检查feeConn中是否有过期连接，有则剔除。

有个地方需要注意的是，Query、Exec操作用法有些差异：

a.Exec(update、insert、delete等无结果集返回的操作)调用完后会自动释放连接； b.Query(返回sql.Rows)则不会释放连接，调用完后仍然占有连接，它将连接的所属权转移给了sql.Rows，所以需要手动调用close归还连接，即使不用Rows也得调用rows.Close()，否则可能导致后续使用出错，如下的用法是错误的：

```go
//错误
db.SetMaxOpenConns(1)
db.Query("select * from test")

row,err := db.Query("select * from test") //此操作将一直阻塞

//正确
db.SetMaxOpenConns(1)
r,_ := db.Query("select * from test")
r.Close() //将连接的所属权归还，释放连接
row,err := db.Query("select * from test")
//other op
row.Close()
```



### 检查点

> 说明：熟悉go原生连接数据库的常用函数



### 2. MySQL数据库（50分钟）

目前Internet上流行的网站构架方式是LAMP，其中的M即MySQL, 作为数据库，MySQL以免费、开源、使用方便为优势成为了很多Web开发的后端数据库存储引擎。

#### 1.1 MySQL驱动

Go中支持MySQL的驱动目前比较多，有如下几种，有些是支持database/sql标准，而有些是采用了自己的实现接口，常用的有如下几种:

- https://github.com/Go-SQL-Driver/MySQL **支持database/sql，全部采用go写。**

- https://github.com/ziutek/mymysql 支持database/sql，也支持自定义的接口，全部采用go写。

- https://github.com/Philio/GoMySQL 不支持database/sql，自定义接口，全部采用go写。


接下来我们主要以第一个驱动为例，也推荐大家采用它，主要理由：

1. 这个驱动比较新，维护的比较好
2. 完全支持database/sql接口
3. 支持keepalive，保持长连接和连接稳定



> 注：以下操作需要开发环境中使用mysql，请同学们自行安装mysql



执行下面命令：

```shell
下载：go get github.com/Go-SQL-Driver/MySQL
```



接下来我们都将采用同一个数据库表结构：数据库mytest，用户表userinfo，关联用户信息表userdetail。

```sql
CREATE TABLE `userinfo` (
`uid` INT(10) NOT NULL AUTO_INCREMENT,
`username` VARCHAR(64) NULL DEFAULT NULL,
`departname` VARCHAR(64) NULL DEFAULT NULL,
`created` DATE NULL DEFAULT NULL,
PRIMARY KEY (`uid`)
)
CREATE TABLE `userdetail` (
`uid` INT(10) NOT NULL DEFAULT '0',
`intro` TEXT NULL,
`profile` TEXT NULL,
PRIMARY KEY (`uid`)
)
```

> 打开mysql数据库：
>
> /usr/local/mysql/bin/mysql -u root -p
>
> 输入密码，启动数据库。

#### 1.2 连接数据库

要想使用Go语言操作mysql，首先需要和mysql数据库建立连接，获取到DB对象。

##### 1.2.1 导入包

首先导入包：

```go
import (
	"database/sql"
	_"github.com/Go-SQL-Driver/MySQL"
)
```

> 1. database/sql，是golang的标准库之一，它提供了一系列接口方法，用于访问关系数据库。它并不会提供数据库特有的方法，那些特有的方法交给数据库驱动去实现。
> 2. 我们正在加载的驱动是匿名的，将其限定符别名为_。

**当导入了一个数据库驱动后, 此驱动会自行初始化并注册自己到Golang的database/sql上下文中, 因此我们就可以通过 database/sql 包提供的方法访问数据库了。**

##### 1.2.2 建立连接

使用Open函数：

```go
func Open(driverName, dataSourceName string) (*DB, error)
/*
其中的两个参数：
    drvierName，这个名字其实就是数据库驱动注册到 database/sql 时所使用的名字.
        "mysql"
    dataSourceName，数据库连接信息，这个连接包含了数据库的用户名, 密码, 数据库主机以及需要连接的数据库名等信息.
        用户名:密码@协议(地址:端口)/数据库?参数=参数值
*/
db, err := sql.Open("mysql", "用户名:密码@tcp(IP:端口)/数据库?charset=utf8")
```

> 例如：db, err := sql.Open("mysql", "root:123456@tcp(127.0.0.1:3306)/test?charset=utf8")

说明：

1. `sql.Open`并不会立即建立一个数据库的网络连接, 也不会对数据库链接参数的合法性做检验, 它仅仅是初始化一个sql.DB对象. 当真正进行第一次数据库查询操作时, 此时才会真正建立网络连接;
2. `sql.DB`表示操作数据库的抽象接口的对象，但不是所谓的数据库连接对象，`sql.DB`对象只有当需要使用时才会创建连接，如果想立即验证连接，需要用`Ping()`方法;
3. `sql.Open`返回的`sql.DB`对象是协程并发安全的.
4. `sql.DB`的设计就是用来作为长连接使用的。不要频繁Open, Close。比较好的做法是，为每个不同的datastore建一个DB对象，保持这些对象Open。如果需要短连接，那么把DB作为参数传入function，而不要在function中Open, Close。

新建go文件(demo02_mysql_open.go)，示例代码：

```go
package main

import (
    "database/sql"
    "fmt"
    _ "github.com/go-sql-driver/mysql"
)

func main() {
    /*
    连接数据库:func Open(driverName, dataSourceName string) (*DB, error)
    Open打开一个dirverName指定的数据库，dataSourceName指定数据源，
    一般包至少括数据库文件名和（可能的）连接信息。

    driverName: 使用的驱动名. 这个名字其实就是数据库驱动注册到 database/sql 时所使用的名字.
    dataSourceName: 数据库连接信息，这个连接包含了数据库的用户名, 密码, 数据库主机以及需要连接的数据库名等信息.

    drvierName,"mysql"
    dataSourceName,用户名:密码@协议(地址:端口)/数据库?参数=参数值

     */

    //"root:123456@tcp(127.0.0.1:3306)/lianshi?charset=utf8"
    db, err := sql.Open("mysql", "root:123456@tcp:(127.0.0.1:3306)/mytest?charset=utf8")
    fmt.Println(db)
    fmt.Println(err)
    if err != nil {
        fmt.Println("连接有误。。")
        return
    }
    fmt.Println("连接成功。。")
    db.Close()

}
```



#### 1.3 DML操作：增删改

##### 1.3.1 操作增删改

有两种方法： 1.直接使用Exec函数添加

```go
func (db *DB) Exec(query string, args ...interface{}) (Result, error)
```

示例代码：

```go
result, err := db.Exec("UPDATE userinfo SET username = ?, departname = ? WHERE uid = ?", "王一博","行政部",2)
```

2.首先使用Prepare获得stmt，然后调用Exec添加。

建立连接后，通过操作DB对象的`Prepare()`方法，可以进行

```go
func (db *DB) Prepare(query string) (*Stmt, error) {
    return db.PrepareContext(context.Background(), query)
}
```

示例代码：

```go
stmt,err:=db.Prepare("INSERT INTO userinfo(username,departname,created) values(?,?,?)") 
//补充完整sql语句，并执行
result,err:=stmt.Exec("杨超越","技术部","2019-11-21")
```

**预编译语句(Prepared Statement)** 提供了诸多好处, 因此我们在开发中尽量使用它. 下面列出了使用预编译语句所提供的功能:

- PreparedStatement 可以实现自定义参数的查询
- PreparedStatement 通常比手动拼接字符串 SQL 语句高效
- PreparedStatement 可以防止SQL注入攻击

##### 1.3.2 处理结果：影响数据库的行数

获取影响数据库的行数，可以根据该数值判断是否插入或删除或修改成功。

```go
 count, err := result.RowsAffected()
```

获得刚刚添加数据的自增ID

```go
id, err := result.LastInsertId()
```

#### 1.4 DQL操作：查询

##### 1.4.1 查询一条

查询单条数据，QueryRow 函数

```go
func (db *DB) QueryRow(query string, args ...interface{}) *Row
```

示例代码：

```go
var username, departname, created string
row := db.QueryRow("SELECT username,departname,created FROM userinfo WHERE uid=?", 3)
err := row.Scan(&username, &departname, &created)

//也可以简写：
err := db.QueryRow("SELECT username,departname,created FROM userinfo WHERE uid=?", 3).Scan(&username, &departname, &created)
```

扫描并复制当前行中每一列的值，但是要求行必须与行中的列数相同。

```go
func (rs *Rows) Scan(dest ...interface{}) error
```

1. `rows.Scan` 参数的顺序很重要, 需要和查询的结果的column对应. 例如 “SELECT * From user where age >=20 AND age < 18” 查询的行的 column 顺序是 “id, name, age” 和插入操作顺序相同, 因此 rows.Scan 也需要按照此顺序 rows.Scan(&id, &name, &age), 不然会造成数据读取的错位.
2. 因为golang是强类型语言，所以查询数据时先定义数据类型，但是查询数据库中的数据存在三种可能:存在值，存在零值，未赋值NULL 三种状态, 因为可以将待查询的数据类型定义为`sql.Nullxxx`类型，可以通过判断Valid值来判断查询到的值是否为赋值状态还是未赋值NULL状态.

##### 1.4.2 查询多条数据，并遍历

Query 获取数据，`for xxx.Next()` 遍历数据：

首先使用Query()方法进行查询，如果查询无误，返回Rows，就是所有行的信息，类似结果集。

```go
func (db *DB) Query(query string, args ...interface{}) (*Rows, error)
```

我们可以通过Next()方法判断是否存在下一条数据，如果有，可以使用之前的Scan()方法读取一行，然后继续判断，继续获取。这个过程的本质就是迭代，所以通常要配合循环使用。

```go
func (rs *Rows) Next() bool
```

每次`db.Query`操作后，都建议调用`rows.Close()`。

因为 `db.Query()` 会从数据库连接池中获取一个连接， 这个底层连接在结果集(rows)未关闭前会被标记为处于繁忙状态。当遍历读到最后一条记录时，会发生一个内部EOF错误，自动调用rows.Close()，但如果提前退出循环，rows不会关闭，连接不会回到连接池中，连接也不会关闭，则此连接会一直被占用。

因此通常我们使用 `defer rows.Close()` 来确保数据库连接可以正确放回到连接池中。

#### 1.5 示例代码：

##### 1.5.1 插入数据

新建go文件(demo03_mysql_insert.go)，示例代码：

```go
package main
// step1：导入包
import (
    "database/sql"
    _"github.com/go-sql-driver/mysql"
    "fmt"
)

func main()  {
    // step2：打开数据库，相当于和数据库建立连接：db对象
    /*
    func Open(driverName, dataSourceName string) (*DB, error)
    drvierName,"mysql"
    dataSourceName,用户名:密码@协议(地址:端口)/数据库?参数=参数值
     */
    db,err:=sql.Open("mysql","root:123456@tcp(127.0.0.1:3306)/mytest?charset=utf8")
    if err !=nil{
        fmt.Println("连接失败。。")
        return
    }

    //step3：插入一条数据

    stmt,err:=db.Prepare("INSERT INTO userinfo(username,departname,created) values(?,?,?)")
    if err !=nil{
        fmt.Println("操作失败。。")
    }
    //补充完整sql语句，并执行
    result,err:=stmt.Exec("杨超越","技术部","2019-11-21")
    if err !=nil{
        fmt.Println("插入数据失败。。")
    }
    //step4：处理sql操作后的结果
    lastInsertId,err:=result.LastInsertId()
    rowsAffected,err:=result.RowsAffected()
    fmt.Println("lastInsertId",lastInsertId)
    fmt.Println("影响的行数：", rowsAffected)

    //再次插入数据：
    result,_=stmt.Exec("lianshi","人事部","2019-11-11")
    count,_:=result.RowsAffected()
    fmt.Println("影响的行数：",count)

    //step5：关闭资源
    stmt.Close()
    db.Close()

}
```

打开数据库，可以看到加入的数据。

##### 1.5.2 更新数据

我们可以按照插入数据的方式，使用Prepare()方法，然后再Exec()。也可以直接执行Exec()。

我们修改uid为2的这条数据，将username由原来的lianshi改为王一博，department由原来的人事部改为行政部。

新建go文件(demo04_mysql_update.go)，示例代码：

```go
package main
// step1：导入包
import (
    "database/sql"
    _"github.com/go-sql-driver/mysql"
    "fmt"
)

func main()  {
    // step2：打开数据库，相当于和数据库建立连接：db对象
    /*
    func Open(driverName, dataSourceName string) (*DB, error)
    drvierName,"mysql"
    dataSourceName,用户名:密码@协议(地址:端口)/数据库?参数=参数值
     */
    db,err:=sql.Open("mysql","root:123456@tcp(127.0.0.1:3306)/mytest?charset=utf8")
    if err !=nil{
        fmt.Println("连接失败。。")
        return
    }

    //step3：修改一条数据，我们直接使用Exec()方法。
    //更新数据

    result, err := db.Exec("UPDATE userinfo SET username = ?, departname = ? WHERE uid = ?", "王一博","行政部",2)
    if err !=nil{
        fmt.Println("更新数据失败。。",err)
    }

    //step4：处理sql操作后的结果
    lastInsertId,err:=result.LastInsertId()
    rowsAffected,err:=result.RowsAffected()
    fmt.Println("lastInsertId",lastInsertId)
    fmt.Println("影响的行数：", rowsAffected)

    //step5：关闭资源
    db.Close()

}
```

##### 1.5.3 查询一条数据

使用QueryRow查询一条数据

新建go文件(demo05_mysql_query_one.go)，示例代码：

```go
package main

import (
    "database/sql"
    _ "github.com/go-sql-driver/mysql"
    "fmt"
)

func main() {
    /*
    查询一条
     */
    db, _ := sql.Open("mysql", "root:123456@tcp(127.0.0.1:3306)/mytest?charset=utf8")

    row := db.QueryRow("SELECT uid,username,departname,created FROM userinfo WHERE uid=?", 1)
    var uid int
    var username, departname, created string
    /*
    row：Scan()-->将查询的结果从row取出
        err对象
        判断err是否为空，
            为空，查询有结果，数据可以成功取出
            不为空，没有数据，sql: no rows in result set
     */
    err := row.Scan(&uid, &username, &departname, &created)

    //fmt.Println(err)
    if err != nil {
        fmt.Println("查无数据。。")
    } else {
        fmt.Println(uid, username, departname, created)

    }
    db.Close()

}
```

运行结果：

![yunxing4](C03L02-GoWeb进阶-数据库.assets/mark-20200204083327221.png)

##### 1.5.4 查询多条

使用Query 获取数据，`for xxx.Next()` 遍历数据。

新建go文件(demo06_mysql_query.go)，示例代码：

```go
package main

//step1：导入包
import (
    "database/sql"
    _ "github.com/go-sql-driver/mysql"
    "fmt"
)

type User struct {
    uid        int
    username   string
    departname string
    created    string
}

func main() {
    /*
    查询操作：
     */
    //step2:打开数据库，建立连接
    db, _ := sql.Open("mysql", "root:123456@tcp(127.0.0.1:3306)/mytest?charset=utf8")

    //stpt3：查询数据库
    rows, err := db.Query("SELECT uid,username,departname,created FROM userinfo")
    if err != nil {
        fmt.Println("查询有误。。")
        return
    }

    //fmt.Println(rows.Columns()) //[uid username departname created]

    //创建slice，存入struct，
    datas := make([] User, 0)
    //step4：操作结果集获取数据
    for rows.Next() {
        var uid int
        var username string
        var departname string
        var created string
        if err := rows.Scan(&uid, &username, &departname, &created); err != nil {
            fmt.Println("获取失败。。")
        }

        //每读取一行，创建一个user对象，存入datas2中
        user := User{uid, username, departname, created}
        datas = append(datas, user)
    }
    //step5：关闭资源
    rows.Close()
    db.Close()

    for _, v := range datas {
        fmt.Println(v)
    }

}

/*
查询：处理查询后的结果：
    思路一：创建结构体
    思路二：将数据，存入到map中
 */
```



也可以操作map来存储查询的结果，这样就不用创建对应的结构体了。

新建go文件(demo07_mysql_query.go)，示例代码：

```go
package main

//step1：导入包
import (
    "database/sql"
    _ "github.com/go-sql-driver/mysql"
    "fmt"
)

func main() {
    /*
    查询操作：
     */
    //step2:打开数据库，建立连接
    db, _ := sql.Open("mysql", "root:123456@tcp(127.0.0.1:3306)/mytest?charset=utf8")

    //stpt3：查询数据库
    rows, err := db.Query("SELECT uid,username,departname,created FROM userinfo")
    if err != nil {
        fmt.Println("查询有误。。")
        return
    }

    //fmt.Println(rows.Columns()) //[uid username departname created]
    //定义一个map，用于存储从数据库中查询出来的数据，字段作为key，string，数据作为value，任意类型，空接口

    datas := make([] map[string]interface{}, 0)

    //step4：操作结果集获取数据
    for rows.Next() {
        var uid int
        var username string
        var departname string
        var created string
        if err := rows.Scan(&uid, &username, &departname, &created); err != nil {
            fmt.Println("获取失败。。")
        }
        map1 := make(map[string]interface{})
        //将读取到的数据，存入了map中
        map1["uid"] = uid
        map1["username"] = username
        map1["departname"] = departname
        map1["created"] = created
        //将map存入切片中
        datas = append(datas, map1)

    }
    //step5：关闭资源
    rows.Close()
    db.Close()

    for _, v := range datas {
        fmt.Println(v)
    }

}

/*
查询：处理查询后的结果：
    思路一：将数据，存入到map中
    思路二：创建结构体：
 */
```



##### 1.5.5 事务

事务操作是通过三个方法实现：

- Begin()：开启事务
- Commit()：提交事务（执行sql)
- Rollback()：回滚

在创建一个表，并插入两条数据：

```sql
CREATE TABLE `account` (
  `id` int(4) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `money` float(8,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
)
INSERT INTO `account` VALUES ('1', '杨超越', '3000.00');
INSERT INTO `account` VALUES ('2', '王一博', '1000.00');
```

现在我们想让杨超越转账给王一博2000元。

如果转账成功，修改杨超越和王一博的金额。否则金额保持不变。

新建go文件(demo08_mysql_transaction.go)，示例代码：

```go
package main

import (
    "database/sql"
    "fmt"
    _ "github.com/go-sql-driver/mysql"
)

func main() {
    /*
    事务：
        4大特性：ACID
        原子性：
        一致性：
        隔离性：
        永久性：
     */
    //杨超越-->王一博,2000元
    db, _ := sql.Open("mysql", "root:123456@tcp(127.0.0.1:3306)/my1802?charset=utf8")
    //开启事务
    tx, _ := db.Begin()
    //提供一组sql操作
    var aff1, aff2 int64 = 0, 0
    result1, _ := tx.Exec("UPDATE account SET money=3000 WHERE id=?", 1)
    result2, _ := tx.Exec("UPDATE account SET money=2000 WHERE id=?", 2)
    //fmt.Println(result2)
    if result1 != nil {
        aff1, _ = result1.RowsAffected()
    }
    if result2 != nil {
        aff2, _ = result2.RowsAffected();
    }
    fmt.Println(aff1)
    fmt.Println(aff2)

    if aff1 == 1 && aff2 == 1 {
        //提交事务
        tx.Commit()
        fmt.Println("操作成功。。")
    } else {
        //回滚
        tx.Rollback()
        fmt.Println("操作失败。。。回滚。。")
    }

}
```



由于事务是一个一直连接的状态，所以Tx对象必须绑定和控制单个连接。一个Tx会在整个生命周期中保存一个连接，然后在调用`commit()`或`Rollback()`的时候释放掉。在调用这几个函数的时候必须十分小心，否则连接会一直被占用直到被垃圾回收。 

#### 1.6 sqlx扩展包

sqlx包是作为database/sql包的一个额外扩展包，在原有的database/sql加了很多扩展，如直接将查询的数据转为结构体，大大简化了代码书写，当然database/sql包中的方法同样起作用。

安装：

```shell
go get "github.com/jmoiron/sqlx"
```

连接数据库：

```go
var Db *sqlx.DB
db, err := sqlx.Open("mysql","username:password@tcp(ip:port)/database?charset=utf8")
Db = db
```

**处理类型（Handle Types)**

sqlx设计和database/sql使用方法是一样的。包含有4中主要的handle types： 

- sqlx.DB - 和sql.DB相似，表示数据库。 
- sqlx.Tx - 和sql.Tx相似，表示事物。 
- sqlx.Stmt - 和sql.Stmt相似，表示prepared statement。 
- sqlx.NamedStmt - 表示prepared statement（支持named parameters）

所有的handler types都提供了对database/sql的兼容，意味着当你调用sqlx.DB.Query时，可以直接替换为sql.DB.Query.这就使得sqlx可以很容易的加入到已有的数据库项目中。

此外，sqlx还有两个cursor类型： 

- sqlx.Rows - 和sql.Rows类似，Queryx返回。 
- sqlx.Row - 和sql.Row类似，QueryRowx返回。

相比database/sql方法还多了新语法，也就是实现将获取的数据直接转换结构体实现。

- Get(dest interface{}, …) error
- Select(dest interface{}, …) error 

**Get 和 Select（非常常用）**

Get和Select是一个非常省时的扩展，可直接将结果赋值给结构体，其内部封装了StructScan进行转化。Get用于获取单个结果然后Scan，Select用来获取结果切片。

新建go文件(demo09_kuozhan.go)，示例代码：

```go
package main

import (
    _ "github.com/go-sql-driver/mysql"
    "github.com/jmoiron/sqlx"
    "fmt"
)

var Db *sqlx.DB

type User struct {
    Uid        int
    Username   string
    Departname string
    Created    string
}

func main() {

    db, err := sqlx.Open("mysql", "root:123456@tcp(127.0.0.1:3306)/mytest?charset=utf8")

    if err != nil {
        fmt.Println("open mysql failed,", err)
        return
    }

    Db = db
    var users []User
    err = Db.Select(&users, "SELECT uid,username,departname,created FROM userinfo")
    if err != nil {
        fmt.Println("Select error", err)
    }
    fmt.Printf("this is Select res:%v\n", users)
    var user User
    err1 := Db.Get(&user, "SELECT uid,username,departname,created FROM userinfo where uid = ?", 1)
    if err1 != nil {
        fmt.Println("GET error :", err1)
    } else {
        fmt.Printf("this is GET res:%v", user)
    }
}

//this is Select res:[{1 杨超越 技术部 2019-11-21} {2 王一博 行政部 2019-11-11}]
//this is GET res:{1 杨超越 技术部 2019-11-21}
```



### 检查点

> 说明：



### 3. Redis数据库（50分钟）

NoSQL(Not Only SQL)，指的是非关系型的数据库。随着Web2.0的兴起，传统的关系数据库在应付Web2.0网站，特别是超大规模和高并发的SNS类型的Web2.0纯动态网站已经显得力不从心，暴露了很多难以克服的问题，而非关系型的数据库则由于其本身的特点得到了非常迅速的发展。

而Go语言作为21世纪的C语言，对NoQL的支持也是很好，目前流行的NoSQL主要有redis、mongoDB、Cassandra和Membase等。这些数据库都有高性能、高并发读写等特点，目前已经广泛应用于各种应用中。



redis是一个key-value存储系统，类似还有Memcached。它支持存储的value类型相对更多，包括字符串（strings）、哈希（hashes）、列表（lists）、集合（sets）、带范围查询的排序集合（sorted sets）、位图（bitmaps）、hyperloglogs、带半径查询和流的地理空间索引等数据结构（geospatial indexes）。

#### 1.1 安装

##### 安装redis

本地docker启动redis server实例

```shell
docker run --name redis507 -p 6379:6379 -d redis:5.0.7
```

本地启动redis-cli连接上面的Redis server

```bash
docker run -it --network host --rm redis:5.0.7 redis-cli
```



##### 安装go连接redis的客户端包

golang操作redis的客户端包有多个比如redigo、go-redis。

github地址：https://github.com/gomodule/redigo

文档：https://godoc.org/github.com/gomodule/redigo/redis

我们可以直接通过go get来安装它。 

```shell
go get github.com/gomodule/redigo/redis
```

#### 1.2 连接

Conn接口是与Redis协作的主要接口，可以使用`Dial,DialWithTimeout或者NewConn`函数来创建连接，当任务完成时，应用程序必须调用Close函数来完成操作。

新建go文件(demo10_redis_open.go)，示例代码：

```go
package main

import (
	"fmt"
	"github.com/gomodule/redigo/redis"
)

func main() {
	conn, err := redis.Dial("tcp", "127.0.0.1:6379")
	if err != nil {
		fmt.Println("connect redis error :", err)
		return
	}
	fmt.Println("connect success ...")
	defer conn.Close()
}
```

#### 1.3 命令操作

通过使用Conn接口中的do方法执行redis命令，常用redis命令：http://doc.redisfans.com/

go中发送与响应对应类型：

Do函数会必要时将参数转化为二进制字符串

| Go Type         | Conversion                          |
| :-------------- | :---------------------------------- |
| []byte          | Sent as is                          |
| string          | Sent as is                          |
| int, int64      | strconv.FormatInt(v)                |
| float64         | strconv.FormatFloat(v, 'g', -1, 64) |
| bool            | true -> "1", false -> "0"           |
| nil             | ""                                  |
| all other types | fmt.Print(v)                        |

Redis 命令响应会用以下Go类型表示：

| Redis type    | Go type                                    |
| :------------ | :----------------------------------------- |
| error         | redis.Error                                |
| integer       | int64                                      |
| simple string | string                                     |
| bulk string   | []byte or nil if value not present.        |
| array         | []interface{} or nil if value not present. |

可以使用Go的类型断言或者reply辅助函数将返回的interface{}转换为对应类型。

##### 1.3.1 get、set操作

新建go文件(demo11_redis_getset.go)，示例代码：

```go
package main

import (
    "github.com/gomodule/redigo/redis"
    "fmt"
)

func main()  {
    conn,err := redis.Dial("tcp","127.0.0.1:6379")
    if err != nil {
        fmt.Println("connect redis error :",err)
        return
    }
    fmt.Println("connect success ...")
    defer conn.Close()
    _, err = conn.Do("SET", "name", "lianshi")
    if err != nil {
        fmt.Println("redis set error:", err)
    }
    name, err := redis.String(conn.Do("GET", "name"))
    if err != nil {
        fmt.Println("redis get error:", err)
    } else {
        fmt.Printf("Got name: %s \n", name)
    }
}
```



##### 1.3.2 设置key过期时间

示例代码：

```go
_, err = conn.Do("expire", "name", 10) // 10秒过期
if err != nil {
    fmt.Println("set expire error: ", err)
    return
}
```

##### 1.3.3 批量获取mget、批量设置mset

新建go文件(demo12_redis_mgetmset.go)，示例代码：

```go
package main

import (
    "github.com/gomodule/redigo/redis"
    "fmt"
    "reflect"
)

func main()  {
    conn,err := redis.Dial("tcp","127.0.0.1:6379")
    if err != nil {
        fmt.Println("connect redis error :",err)
        return
    }
    fmt.Println("connect success ...")
    defer conn.Close()
    _, err = conn.Do("MSET", "name", "lianshi","age", 18)
    if err != nil {
        fmt.Println("redis mset error:", err)
    }
    res, err := redis.Strings(conn.Do("MGET", "name","age"))
    if err != nil {
        fmt.Println("redis get error:", err)
    } else {
        res_type := reflect.TypeOf(res)
        fmt.Printf("res type : %s \n", res_type)
        fmt.Printf("MGET name: %s \n", res)
        fmt.Println(len(res))
    }
    //结果：
    //connect success ...
    //res type : []string
    //MGET name: [lianshi 18]
    //2
}
```

##### 1.3.4 列表操作

新建go文件(demo13_redis_list.go)，示例代码：

```go
package main

import (
    "github.com/gomodule/redigo/redis"
    "fmt"
    "reflect"
)

func main() {
    conn, err := redis.Dial("tcp", "127.0.0.1:6379")
    if err != nil {
        fmt.Println("connect redis error :", err)
        return
    }
    fmt.Println("connect success ...")
    defer conn.Close()
    _, err = conn.Do("LPUSH", "list1", "ele1", "ele2", "ele3", "ele4")
    if err != nil {
        fmt.Println("redis mset error:", err)
    }
    //res, err := redis.String(conn.Do("LPOP", "list1"))//获取栈顶元素
    //res, err := redis.String(conn.Do("LINDEX", "list1", 3)) //获取指定位置的元素
    res, err := redis.Strings(conn.Do("LRANGE", "list1", 0, 3)) //获取指定下标范围的元素
    if err != nil {
        fmt.Println("redis POP error:", err)
    } else {
        res_type := reflect.TypeOf(res)
        fmt.Printf("res type : %s \n", res_type)
        fmt.Printf("res  : %s \n", res)
    }
    //结果：
    //  connect success ...
    //  res type : string
    //  res  : [ele4 ele3 ele2 ele1]
}
```



##### 1.3.5 hash操作

新建go文件(demo14_redis_hash.go)，示例代码：

```go
package main

import (
    "github.com/gomodule/redigo/redis"
    "fmt"
    "reflect"
)

func main() {
    conn, err := redis.Dial("tcp", "127.0.0.1:6379")
    if err != nil {
        fmt.Println("connect redis error :", err)
        return
    }
    fmt.Println("connect success ...")
    defer conn.Close()
    _, err = conn.Do("HSET", "user","name", "lianshi","age",18)
    if err != nil {
        fmt.Println("redis mset error:", err)
    }
    res, err := redis.Int64(conn.Do("HGET", "user","age"))
    if err != nil {
        fmt.Println("redis HGET error:", err)
    } else {
        res_type := reflect.TypeOf(res)
        fmt.Printf("res type : %s \n", res_type)
        fmt.Printf("res  : %d \n", res)
    }
    //结果：
    //  connect success ...
    //  res type : int64
    //res  : 18
}
```

##### 1.3.6 Pipeline(管道)

管道操作可以理解为并发操作，并通过`Send()，Flush()，Receive()`三个方法实现。客户端可以使用send()方法一次性向服务器发送一个或多个命令，命令发送完毕时，使用flush()方法将缓冲区的命令输入一次性发送到服务器，客户端再使用`Receive()`方法依次按照先进先出的顺序读取所有命令操作结果。

```go
Send(commandName string, args ...interface{}) error
Flush() error
Receive() (reply interface{}, err error)
```

- Send：发送命令至缓冲区
- Flush：清空缓冲区，将命令一次性发送至服务器
- Recevie：依次读取服务器响应结果，当读取的命令未响应时，该操作会阻塞。

新建go文件(demo15_redis_pipelining.go)，示例代码：

```go
package main

import (
    "github.com/gomodule/redigo/redis"
    "fmt"
)

func main() {
    conn, err := redis.Dial("tcp", "127.0.0.1:6379")
    if err != nil {
        fmt.Println("connect redis error :", err)
        return
    }
    fmt.Println("connect success ...")
    conn.Send("HSET", "user","name", "lianshi","age","30")
    conn.Send("HSET", "user","sex","female")
    conn.Send("HGET", "user","age")
    conn.Flush()

    res1, err := conn.Receive()
    fmt.Printf("Receive res1:%v \n", res1)
    res2, err := conn.Receive()
    fmt.Printf("Receive res2:%v\n",res2)
    res3, err := conn.Receive()
    fmt.Printf("Receive res3:%s\n",res3)
    //结果：
    //  connect success ...
    //  res type : string
    //  res  : [ele4 ele3 ele2 ele1]
}
```



##### 1.3.7 发布/订阅

redis本身具有发布订阅的功能，其发布订阅功能通过命令`SUBSCRIBE(订阅)／PUBLISH(发布)`实现，并且发布订阅模式可以是多对多模式还可支持正则表达式，发布者可以向一个或多个频道发送消息，订阅者可订阅一个或者多个频道接受消息。

操作示例，示例中将使用两个goroutine分别担任发布者和订阅者角色进行演示：

新建go文件(demo16_redis_pub_sub.go)：

```go
package main

import (
    "github.com/gomodule/redigo/redis"
    "fmt"
    "time"
)

func Subs() { //订阅者
	conn, err := redis.Dial("tcp", "127.0.0.1:6379")
	if err != nil {
		fmt.Println("connect redis error :", err)
		return
	}
	defer conn.Close()
	psc := redis.PubSubConn{conn}
	psc.Subscribe("channel1") //订阅channel1频道
	for {
		switch v := psc.Receive().(type) {
		case redis.Message:
			fmt.Printf("%s: message: %s\n", v.Channel, v.Data)
		case redis.Subscription:
			fmt.Printf("%s: %s %d\n", v.Channel, v.Kind, v.Count)
		case error:
			fmt.Println(v)
			return
		}
	}
}

func Push(message string) { //发布者
	conn, _ := redis.Dial("tcp", "127.0.0.1:6379")
	_, err1 := conn.Do("PUBLISH", "channel1", message)
	if err1 != nil {
		fmt.Println("pub err: ", err1)
		return
	}

}

func main() {
	go Subs()
	go Push("this is lianshi")
	time.Sleep(time.Second * 5)
}
// channel1: subscribe 1
// channel1: message: this is lianshi
```



#### 1.4 事务操作

`MULTI, EXEC,DISCARD,WATCH`是构成Redis事务的基础，当然我们使用go语言对redis进行事务操作的时候本质也是使用这些命令。

- `MULTI`：开启事务
- `EXEC` ：执行事务
- `DISCARD`：取消事务
- `WATCH`：监视事务中的键变化，一旦有改变则取消事务。

##### MULTI操作

新建go文件(demo17_redis_transaction.go)，示例代码：

```go
package main

import (
    "github.com/gomodule/redigo/redis"
    "fmt"
)

func main()  {
    conn, err := redis.Dial("tcp", "127.0.0.1:6379")
    if err != nil {
        fmt.Println("connect redis error :", err)
        return
    }
    fmt.Println("connect success ...")
    defer conn.Close()

    conn.Send("MULTI")
    conn.Send("INCR", "foo")
    conn.Send("INCR", "bar")
    r, err := conn.Do("EXEC")
    fmt.Println(r)
}
//connect success ...
//[1 1]
```

##### watch操作

WATCH命令可以监控一个或多个键,一旦其中有一个键被修改(或删除),之后的事务就不会执行。

```go
package main

import (
    "github.com/gomodule/redigo/redis"
    "fmt"
)

func main()  {
    conn, err := redis.Dial("tcp", "127.0.0.1:6379")
    if err != nil {
        fmt.Println("connect redis error :", err)
        return
    }
    fmt.Println("connect success ...")
    defer conn.Close()

	conn.Do("SET", "xo", 10)
	conn.Do("WATCH", "xo")
	v, _ := redis.Int64(conn.Do("GET", "xo"))
	v = v + 1 // 这里可以基于值做一些判断逻辑
	conn.Send("MULTI")
	conn.Send("SET", "xo", v)
	r, err := conn.Do("EXEC")
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(r)
}
```

在获取`xo`的值之前先通过`WATCH`命令监控了该键，此后又将`set`命令包围在事务中，这样就可以有效的保证每个连接在执行EXEC之前，如果当前连接获取的`xo`的值被其它连接的客户端修改，那么当前连接的EXEC命令将执行失败。这样调用者在判断返回值后就可以获悉val是否被重新设置成功。

**注意事项**

- 由于WATCH命令的作用只是当被监控的键值被修改后阻止之后一个事务的执行，而不能保证其他客户端不修改这一键值，所以在一般的情况下我们需要在EXEC执行失败后重新执行整个函数。
- 执行EXEC命令后会取消对所有键的监控，如果不想执行事务中的命令也可以使用`UNWATCH`命令来取消监控。

#### 1.5 连接池使用

redis连接池是通过pool结构体实现，以下是源码定义，相关参数说明已经备注：

```go
type Pool struct {
    // Dial is an application supplied function for creating and configuring a
    // connection.
    //
    // The connection returned from Dial must not be in a special state
    // (subscribed to pubsub channel, transaction started, ...).
    Dial func() (Conn, error) //连接方法

    // TestOnBorrow is an optional application supplied function for checking
    // the health of an idle connection before the connection is used again by
    // the application. Argument t is the time that the connection was returned
    // to the pool. If the function returns an error, then the connection is
    // closed.
    TestOnBorrow func(c Conn, t time.Time) error

    // Maximum number of idle connections in the pool.
    MaxIdle int  //最大的空闲连接数，即使没有redis连接时依然可以保持N个空闲的连接，而不被清除，随时处于待命状态

    // Maximum number of connections allocated by the pool at a given time.
    // When zero, there is no limit on the number of connections in the pool.
    MaxActive int //最大的激活连接数，同时最多有N个连接

    // Close connections after remaining idle for this duration. If the value
    // is zero, then idle connections are not closed. Applications should set
    // the timeout to a value less than the server's timeout.
    IdleTimeout time.Duration  //空闲连接等待时间，超过此时间后，空闲连接将被关闭

    // If Wait is true and the pool is at the MaxActive limit, then Get() waits
    // for a connection to be returned to the pool before returning.
    Wait bool  //当配置项为true并且MaxActive参数有限制时候，使用Get方法等待一个连接返回给连接池

    // Close connections older than this duration. If the value is zero, then
    // the pool does not close connections based on age.
    MaxConnLifetime time.Duration
    // contains filtered or unexported fields
}
```

新建go文件(demo18_redis_pool.go)，示例代码：

```go
package main

import (
	"fmt"
	"github.com/gomodule/redigo/redis"
	"time"
)

var Pool redis.Pool

func init() { // init 用于初始化一些参数，先于main执行
	Pool = redis.Pool{
		MaxIdle:     16,
		MaxActive:   32,
		IdleTimeout: 120,
		Dial: func() (redis.Conn, error) {
			c, err := redis.Dial("tcp", "127.0.0.1:6379",
				redis.DialConnectTimeout(30 * time.Millisecond),
				redis.DialReadTimeout(5 * time.Millisecond),
				redis.DialWriteTimeout(5 * time.Millisecond))
			if err != nil {
				fmt.Println(err)
				return nil, err
			}
			return c, nil
		},
	}
}

func someFunc() {
	conn := Pool.Get()
	defer conn.Close()
	res, err := conn.Do("HSET", "user", "name", "lianshi")
	fmt.Println(res, err)
	res1, err := redis.String(conn.Do("HGET", "user", "name"))
	fmt.Printf("res:%s,error:%v\n", res1, err)
	//...
}
func main() {

	someFunc()

}
//0 <nil>
//res:lianshi,error:<nil>
```

##### 密码认证和选择指定数据库

```go
pool := &redis.Pool{
  // 其他配置同上，这里就省略了...
  Dial: func () (redis.Conn, error) {
    c, err := redis.Dial("tcp", server)
    if err != nil {
      return nil, err
    }
    // auth认证
    if _, err := c.Do("AUTH", password); err != nil {
      c.Close()
      return nil, err
    }
    // 使用select指令选择数据库
    if _, err := c.Do("SELECT", db); err != nil {
      c.Close()
      return nil, err
    }
    return c, nil
  },
}
```

##### 连接检测

在将连接返回给应用程序之前，使用`TestOnBorrow`函数检查空闲连接的健康状况。

下面的示例是对空闲超过一分钟的连接执行`ping`命令检测连接是否可用:

```go
pool := &redis.Pool{
  // 其他配置同上，这里就省略了...
  // 
  TestOnBorrow: func(c redis.Conn, t time.Time) error {
    if time.Since(t) < time.Minute {
      return nil
    }
    _, err := c.Do("PING")
    return err
  },
}
```

### redis集群

`codis`   `redis-cluster`



## 五、拓展点（10分钟）

> 



## 六、总结（5分钟）

##### redis场景

也是一个应用类工具，一定想办法把它用起来。。。

ZSET:榜单、排行榜、定时任务

INCR点赞

LIST 管理后台发通知邮件/短信 

去重

缓存 --> 把热点数据缓存起来，缩短响应时间



想获取更多的redis应用场景，就要多看书《Redis开发与运维》 《redis实战》，多看网上大厂的技术分享



##### 面试会问的：

redis 常用的数据结构底层实现是什么？  ziplist、跳跃表

缓存雪崩 、缓存击穿。。。



##### redis优化

key的优化

key尽量都要设置过期时间

一级key数量不要太多

bigkey尽量少

key分级

- shop_userinfo_1000 

- shop_userinfo_2000

集群

持久化

AOF 和 RDB



GORM 

> 说明：
>
> 回顾本堂课所有知识点；
>
> Go如何设计database/sql接口，然后介绍了第三方关系型数据库驱动的使用，比如MySQL。接着介绍了NOSQL的一些知识，我们使用的是Redis，大家也可以自己学习一下其他的的NOSQL数据库，目前Go对于NOSQL支持还是不错，因为Go作为21世纪的C语言，那么对于21世纪的数据库也是支持的相当好。


