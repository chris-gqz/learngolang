package main

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

func loginFunc(c *gin.Context)  {
	c.HTML(http.StatusOK, "index.html", nil)
}

func PostFunc(c *gin.Context)  {
	// 从请求中获取邮箱和密码 数据
	// 去数据库MySQL中查询该用户名是否存在
	// 1. 存在就跳转到/home页面
	// 2. 不存在返回一个用户名或密码错误的提示
	c.HTML(http.StatusOK, "index.html", nil)
}

func main() {
	r := gin.Default()

	r.Static("/static", "static")
	// 1. 定义模板
	// 2. 解析模板
	r.LoadHTMLGlob("templates/*")
	// 3. 渲染模板

	r.GET("/login", loginFunc)
	r.POST("/login", PostFunc)

	//r.Any("/login", loginFunc)

	r.Run()
}
