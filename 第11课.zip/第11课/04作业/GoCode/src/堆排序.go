package main

import "fmt"




//构建堆数据结构
func HeapAdjust(slice []int, parent, len int) {
	temp := slice[parent]
	//子结点的位置=2*（父结点位置）+1
	child := 2*parent + 1

	for child < len {
		//得到子结点中较大的结点
		if child+1 < len && slice[child] < slice[child+1] {
			child++
		}

		//如果较大的子结点大于父结点，那么把较大的子结点往上移动，替换它的父结点 否则退出循环
		if child < len && slice[child] <= temp {
			break
		}

		slice[parent] = slice[child]

		parent = child
		child = child*2 + 1
	}

	slice[parent] = temp
}

func HeadSort(slice []int) {
	//对序列中的每个非叶子结点执行调整算法，使该序列成为一个堆
	for i := len(slice) / 2; i >= 0; i-- {
		HeapAdjust(slice, i, len(slice))
	}
	//从最后一个元素开始对序列进行调整，不断缩小调整的范围直到第一个元素
	for i := len(slice) - 1; i > 0; i-- {
		slice[0], slice[i] = slice[i], slice[0]

		HeapAdjust(slice, 0, i)
	}
}
func main() {
	slice := []int{9, 1, 5, 6, 10, 8, 3, 7, 2, 4}
	HeadSort(slice)
	fmt.Println(slice)
}
