package main

import "fmt"

func main04() {
	//去市场买黄瓜  3.25/斤  买5斤
	price := 3.99
	weight := 5
	//类型转换不会四舍五入
	fmt.Println(price * float64(weight))      //16.25
	fmt.Println(int(price) * weight)          //15
	fmt.Println(int(price * float64(weight))) //16

}
