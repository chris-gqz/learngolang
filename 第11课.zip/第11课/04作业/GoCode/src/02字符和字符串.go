package main

import "fmt"

func main01() {
	var ch byte = 'a'
	fmt.Println(ch)
	fmt.Printf("%c\n", ch)

	//uncode编码
	var b rune = '帅'
	fmt.Println(b)
	fmt.Printf("%c\n", b)
}

func main() {
	str := "你瞅啥"
	//fmt.Println(str)
	//fmt.Printf("%s\n", str)
	////计算一个字符串中字符的个数  一个汉字占三个字节
	//fmt.Println(len(str))
	//字符串连接  +
	fmt.Println(str + "老弟")
	if str == "你瞅啥" {
		fmt.Println("相同")
	}

	//在使用时有些符号被赋予了特定意义  使用转义字符 获取本意
	//D:\\Desktop\\练识课堂Go语言高新课程\\第01讲\\03资料

	//使用反引号 内如原样输出
	str1 := `瞅你咋地\n 不服就插架`
	fmt.Println(str1)
	fmt.Printf("%T\n", str1)

}
