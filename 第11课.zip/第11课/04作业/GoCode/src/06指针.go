package main

import "fmt"

func main0601() {
	var a int = 10
	fmt.Println(&a)
	//可以将变量的地址复制给指针类型
	//var 指针变量 *数据类型

	//& 取地址运算符
	var p *int = &a
	//* 取值运算符
	//指针间接修改变量的值
	*p = 123
	fmt.Println(a)

	fmt.Println(p)
}
func main() {
	//内存地址编号0到255为系统占用不允许用户读写操作
	var p *int = nil //nil
	//new  创建内存空间  不需要关心释放问题
	p = new(int)
	*p = 123
	fmt.Println(*p)
}
