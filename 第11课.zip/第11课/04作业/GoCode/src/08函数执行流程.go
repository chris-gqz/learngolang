package main

import "fmt"

func add(a int, b int) int {
	sum := a + b
	return sum
}

const MAX = 100

func main() {
	a := 10
	b := 20
	const PI = 3.14
	value := add(a, b)
	fmt.Println(value)
}
