package main

/*
#include <stdio.h>

void Print()
{
	printf("hello world");
	return;
}
*/
import "C"

func main() {
	//在GO语言中调用C语言代码
	C.Print()
}
