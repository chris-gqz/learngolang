package main

//调用C语言函数传递参数

/*
int add(int a, int b)
{
	return a + b;
}
*/
import "C"
import "fmt"

func main() {
	a := 10 //go:int int64  C:long long int
	b := 20
	value := C.add(C.int(a), C.int(b))
	fmt.Println(value)
	fmt.Printf("%T\n", value) //main._Ctype_int
	//做类型转换  将C语言类型转成go语言类型
	fmt.Println(int(value) + a)
}
