package main

import (
	"fmt"
	"html/template"
	"log"
	"net/http"
	"time"
)

type Item struct {
	Name  string
	Price int
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	// 客户端访问 /login ,服务端就会执行这个函数
	// 返回一个登录页面
	//b, _ := ioutil.ReadFile("login.html")
	//fmt.Fprint(w, string(b))
	// 根据请求方法的不同做不同的动作，返回不同的响应

	if r.Method == http.MethodPost{
		// 用户登录提交数据到这里
		// 服务端根据用户填写的用户名和密码来做判断，
		r.ParseForm()
		username := r.FormValue("username")
		pwd := r.FormValue("password")
		// 如果name=lianshi & password=123456 就返回欢迎lianshi 同学
		if username == "lianshi" && pwd == "123456" {
			// 顺便给你发一张卡片（cookie）
			c1 := &http.Cookie{
				Name:       "username",
				Value:      username,
				MaxAge:     0,
				HttpOnly:   true,
			}
			http.SetCookie(w, c1)
			fmt.Fprint(w, "登陆成功")
		}else{
			//否则返回登陆失败。
			fmt.Fprint(w, "登陆失败")
		}
	}else {
		t, _ := template.ParseFiles("login.html")       // 解析模板
		now := time.Now().Format("2006/01/02 15:04:05") // yyyy:mm:dd
		items := []Item{
			{"iPhone", 699},
			{"iPad", 799},
			{"iWatch", 199},
			{"MacBook", 999},
		}
		data := map[string]interface{}{
			"now":   now,
			"items": items,
			//"comment": template.HTML("<script>alert(123);</script>"),
		}
		t.Execute(w, data) // 渲染
	}



}

func userInfoHandler(w http.ResponseWriter, r *http.Request){
	// 返回当前请求的用户的个人信息
	// 我怎么知道当前请求的用户是谁？
	// 从请求中查看是否有之前保存的cookie信息
	username, _ := r.Cookie("username")

	// 拿到cookie中的username 展示到页面上
	t, _ := template.ParseFiles("user_info.html")
	t.Execute(w, username.Value)
}

func contextAwareHandler(w http.ResponseWriter, r *http.Request) {
	t := template.Must(template.ParseFiles("context-aware.html"))
	t.Execute(w, `He saied: <i>"She's alone?"</i>`)
}

func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("/login", loginHandler)
	mux.HandleFunc("/user_info", userInfoHandler)
	mux.HandleFunc("/contextAware", contextAwareHandler)

	server := &http.Server{
		Addr:    ":8080",
		Handler: mux,
	}

	if err := server.ListenAndServe(); err != nil {
		log.Fatal(err)
	}
}
