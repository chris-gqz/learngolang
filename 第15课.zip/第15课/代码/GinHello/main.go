package main

import (
	initRouter "GinHello/initrouter"
)

func main() {
	router := initRouter.SetupRouter()

	err := router.Run()
	if err != nil {
		panic(err)
	}
}
