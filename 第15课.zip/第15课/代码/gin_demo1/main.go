package main

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"log"
	"net/http"
	"time"
)

func indexFunc(c *gin.Context) {
	c.String(http.StatusOK, c.Request.Method)
}

func Func404(c *gin.Context) {
	c.String(http.StatusNotFound, "你请求的网页不见了。。。")
}

func postFunc(c *gin.Context) {
	// 根据用户请求的年份也月份去数据库中查找对应的数据
	// c.Request  --> http.Request 所有跟请求相关的内容
	// c.Params
	year := c.Param("year")   // string
	month := c.Param("month") // string
	// QueryString参数
	//c.Query("author")
	author := c.DefaultQuery("author", "xxx")
	c.String(http.StatusOK, fmt.Sprintf("year:%v month:%v author:%v", year, month, author)) // 返回响应
}

func formFunc(c *gin.Context) {
	type1 := c.DefaultPostForm("type", "alert") //可设置默认值
	username := c.PostForm("username")
	password := c.PostForm("password")

	//hobbys := c.PostFormMap("hobby")
	//hobbys := c.QueryArray("hobby")
	hobbys := c.PostFormArray("hobby")

	c.String(http.StatusOK, fmt.Sprintf("type is %s, username is %s, password is %s,hobby is %v", type1, username, password, hobbys))
}

func uploadFunc(c *gin.Context) {
	// single file
	file, _ := c.FormFile("file")
	log.Println(file.Filename)

	// Upload the file to specific dst.
	c.SaveUploadedFile(file, file.Filename)

	/*
	   也可以直接使用io操作，拷贝文件数据。
	   out, err := os.Create(filename)
	   defer out.Close()
	   _, err = io.Copy(out, file)
	*/

	c.String(http.StatusOK, fmt.Sprintf("'%s' uploaded!", file.Filename))
}
func main() {
	// 创建默认的路由器
	r := gin.Default()
	// 注册一条路由， / --> indexFunc
	//r.GET("/", indexFunc)
	//r.POST("/", indexFunc)
	//r.OPTIONS("/", indexFunc)
	//r.PUT("/", indexFunc)
	//r.DELETE("/", indexFunc)
	//r.PATCH("/", indexFunc)
	// Any
	r.Any("/", indexFunc)
	// NoRoute
	r.NoRoute(Func404)
	r.GET("/post/:year/:month", postFunc)
	//r.GET("/post/2020/01", Funcxx)
	//r.GET("/post/2020/02", Funcxx)
	r.POST("/form", formFunc)
	r.POST("/upload", uploadFunc)
	// 启动server
	// 1
	//r.Run()
	// 2
	//err := http.ListenAndServe(":8080", r)
	//if err != nil {
	//	panic(err)
	//}
	// 3
	s := &http.Server{
		Addr:           ":8080",
		Handler:        r,
		ReadTimeout:    10 * time.Second,
		WriteTimeout:   10 * time.Second,
		MaxHeaderBytes: 1 << 20,
	}
	err := s.ListenAndServe()
	if err != nil {
		panic(err)
	}
}
