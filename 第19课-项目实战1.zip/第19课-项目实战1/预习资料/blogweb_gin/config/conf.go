package config

// 定义查询文章，每页显示的文章量
const NUM  = 5