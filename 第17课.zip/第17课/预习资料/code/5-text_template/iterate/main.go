package main

import (
	"log"
	"os"
	"text/template"
)

type Item struct {
	Name  string
	Price int
}

func main() {
	t, err := template.ParseFiles("test")
	if err != nil {
		log.Fatal("Parse error:", err)
	}

	// items := []Item {
	// 	{ "iPhone", 699 },
	// 	{ "iPad", 799 },
	// 	{ "iWatch", 199 },
	// 	{ "MacBook", 999 },
	// }
	var items []Item

	err = t.Execute(os.Stdout, items)
	if err != nil {
		log.Fatal("Execute error:", err)
	}
}
