package main

import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"  // init()
)

func main(){
	db, err := sql.Open("mysql", "root:root1234@tcp(127.0.0.1:3306)/test1?charset=utf8mb4")
	if err != nil {
		fmt.Println("创建数据库对象db失败")
		return
	}
	defer db.Close()  // db对象创建成功之后才可能调用它的Close方法
	err = db.Ping()  // 真正尝试去连数据库
	if err != nil {
		fmt.Printf("连接数据库失败，err:%v\n", err)
		return
	}
	fmt.Println("连接数据库成功。。")
	// db 数据库连接池
	db.SetMaxOpenConns(500)  // 最大连接数
	db.SetMaxIdleConns(100)  // 最大空闲连接数据，业务低峰期保留多少连接
	//db.SetConnMaxLifetime(30 * time.Second)  // 连接空闲时间

	//result, err := db.Exec("INSERT INTO userinfo(username,departname,created) values(?,?,?)", "杨超越","技术部","2019-11-21")
	//if err != nil {
	//	fmt.Printf("插入数据失败:%v\n", err)
	//	return
	//}
	//fmt.Println(result.LastInsertId()) // 最后插入的数据的id
	//fmt.Println(result.RowsAffected()) // 返回受影响的行数

	// 预编译
	//stmt, err:=db.Prepare("INSERT INTO userinfo(username,departname,created) values(?,?,?)")
	//if err != nil {
	//	fmt.Printf("prepare 失败，err:%v\n", err)
	//	return
	//}
	////补充完整sql语句，并执行
	//result, err := stmt.Exec("程潇","体操部","2020-02-29")
	//if err != nil {
	//	fmt.Printf("插入数据失败,err:%v\n", err)
	//	return
	//}
	//fmt.Println(result.LastInsertId()) // 最后插入的数据的id
	//fmt.Println(result.RowsAffected()) // 返回受影响的行数

	// 查询
	var username sql.NullString
	var departname, created string
	row := db.QueryRow("SELECT username,departname,created FROM userinfo WHERE uid=?", 2)
	err = row.Scan(&username, &departname, &created)
	if err != nil {
		fmt.Printf("QueryRow failed, err:%v\n", err)
		return
	}
	fmt.Println(username.Valid)
	fmt.Println(username.String)
	fmt.Println(username, departname, created)

	//也可以简写：
	err = db.QueryRow("SELECT username,departname,created FROM userinfo WHERE uid=?", 2).Scan(&username, &departname, &created)
	if err != nil {
		fmt.Printf("QueryRow failed, err:%v\n", err)
		return
	}
	fmt.Println(username, departname, created)
	// 数据库的值如果想知道是不是有值 应该使用Null

	// 查询多条
	sqlStr := `select username, departname, created from userinfo where id > ?`
	rows, err := db.Query(sqlStr, 0)
	if err != nil {
		return
	}
	defer rows.Close()  // 释放rows占用的数据库连接
	for rows.Next(){
		err = rows.Scan(&username, &departname, &created)
		if err != nil {
			return
		}
	}
	// 注册把数据写入mysql数据库
	// 登录从MySQL数据库检索数据是否存在
}