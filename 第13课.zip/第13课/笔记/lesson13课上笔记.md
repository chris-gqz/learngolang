## 课上代码

### 全用默认的

```go
package main

import (
    "fmt"
    "log"
    "net/http"
)

func hello(w http.ResponseWriter, r *http.Request) {
    fmt.Fprintf(w, "Hello, Web!")
}

func main() {
    http.HandleFunc("/", hello)
    if err := http.ListenAndServe(":8080", nil); err != nil {
        log.Fatal(err)
    }
}
```

### 自定义mux模式

```go
package main

import (
	"fmt"
	"log"
	"net/http"
)

func hello(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Hello, Web")
}

func main() {
  //创建Mux
	mux := http.NewServeMux()
	mux.HandleFunc("/", hello)

	server := &http.Server{
		Addr:    ":8080",
		Handler: mux,	//注册处理器
	}

	if err := server.ListenAndServe(); err != nil {
		log.Fatal(err)
	}
}
```

### mux.Handle注册模式

```go
package main

import (
	"fmt"
	"log"
	"net/http"
)

type GreetingHandler struct {
	Language string
}

func (h GreetingHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "%s", h.Language)
}

func main() {
	mux := http.NewServeMux()
	//mux.HandleFunc()
	//mux.Handle(URL, Handler接口:实现ServerHTTP方法)
	mux.Handle("/chinese", GreetingHandler{Language: "你好"})
	mux.Handle("/english", GreetingHandler{Language: "Hello"})

	server := &http.Server {
		Addr:   ":8080",
		Handler: mux,
	}

	if err := server.ListenAndServe(); err != nil {
		log.Fatal(err)
	}
}
```

## net/http中关键点

![image-20200215214735525](\lesson13课上笔记.assets\image-20200215214735525.png)

## 作业

1. 安装postman
2. 使用net/http标准库，编写一个服务端，注册一个`/json`的URL及其处理函数，拿到json格式数据