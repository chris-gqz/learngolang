package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
)

func indexHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "This is the index page")
}

func helloHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "This is the hello page")
}

func worldHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "This is the world page")
}

// 请求URL部分信息
func urlHandler(w http.ResponseWriter, r *http.Request) {
	// r *http.Request 所有跟请求相关的都在这里面找
	// w http.ResponseWriter 所有跟响应相关的都在这里面找


	URL := r.URL // net/url.URL	 // URL部分信息

	fmt.Fprintf(w, "Scheme: %s\n", URL.Scheme)
	fmt.Fprintf(w, "Host: %s\n", URL.Host)
	fmt.Fprintf(w, "Path: %s\n", URL.Path)
	fmt.Fprintf(w, "RawPath: %s\n", URL.RawPath)
	fmt.Fprintf(w, "RawQuery: %s\n", URL.RawQuery)
	fmt.Fprintf(w, "Fragment: %s\n", URL.Fragment)
}
// 查看Header信息的函数
func headerHandler(w http.ResponseWriter, r *http.Request) {
	//r.Header // 请求头信息
	for key, value := range r.Header {
		fmt.Fprintf(w, "%s: %v\n", key, value)
	}
}

// 查看请求的内容体
func bodyHandler(w http.ResponseWriter, r *http.Request) {
	data := make([]byte, r.ContentLength)

	//r.Body
	r.Body.Read(data) // 忽略错误处理
	defer r.Body.Close()
	// 将 从请求中读取的内容再写入响应体中
	fmt.Println(string(data))
	// 检查用户名密码是否正确 --> 连接数据库判断用户名密码是否正确
	fmt.Fprintln(w, string(data))
}

// 当请求时form表单数据时，可以使用r.ParseForm解析请求数据
func form2Handler(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()
	fmt.Println(r.Form)
	fmt.Fprintln(w, "收到了!")
}

// 返回HTML代码的一个处理函数
func formHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprint(w, `
<html>
    <head>
        <title>Go Web</title>
    </head>
    <body>
        <form method="post" action="/body">
            <label for="username">用户名：</label>
            <input type="text" id="username" name="username">
            <label for="email">邮箱：</label>
            <input type="text" id="email" name="email">
            <button type="submit">提交</button>
        </form>
    </body>
</html>
`)
}
func index2Handler(w http.ResponseWriter, r *http.Request){
	fmt.Fprintln(w, `<html>
    <head>
        <title>Go Web</title>
    </head>
    
    <body>
        <form action="/form2?lang=cpp&name=ls" method="post" enctype="application/x-www-form-urlencoded">
            <label>Form:</label>
            <input type="text" name="lang" />
            <input type="text" name="age" />
            <button type="submit">提交</button>
        </form>
    </body>
</html>`)
}

// 返回上传文件页面
func fileHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintln(w, `
<html>
    <head>
        <title>Go Web</title>
    </head>
    <body>
<form action="/multipartform?lang=cpp&name=dj" method="post" enctype="multipart/form-data">
	<label>MultipartForm:</label>
    <input type="text" name="lang" />
    <input type="text" name="age" />
    <input type="file" name="uploaded" />
    <input type="file" name="uploaded2" />
    <button type="submit">提交</button>
</form>
    </body>
</html>`)
}
func multipartFormHandler(w http.ResponseWriter, r *http.Request) {
	r.ParseMultipartForm(4096)
	fileHeader := r.MultipartForm.File["uploaded"][0]
	//fileHeader2 := r.MultipartForm.File["uploaded2"][0]
	file, err := fileHeader.Open()
	if err != nil {
		fmt.Println("Open failed: ", err)
		return
	}

	data, err := ioutil.ReadAll(file)
	if err == nil {
		ioutil.WriteFile("xx.xlsx", data, 0777)
	}

	fmt.Fprintln(w, "收到了")
}



func main() {
	mux := http.NewServeMux()
	//mux.Handle()
	mux.HandleFunc("/", indexHandler)
	mux.HandleFunc("/hello/", helloHandler)
	mux.HandleFunc("/hello/world/", worldHandler)
	mux.HandleFunc("/url", urlHandler)
	mux.HandleFunc("/header", headerHandler)
	mux.HandleFunc("/body", bodyHandler)
	mux.HandleFunc("/form", formHandler)

	mux.HandleFunc("/index2", index2Handler)
	mux.HandleFunc("/form2", form2Handler)

	mux.HandleFunc("/file", fileHandler)
	mux.HandleFunc("/multipartform", multipartFormHandler)


	server := &http.Server{
		Addr:    ":8080",
		Handler: mux,
	}

	if err := server.ListenAndServe(); err != nil {
		log.Fatal(err)
	}
}

