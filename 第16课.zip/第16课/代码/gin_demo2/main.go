package main

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"html/template"
	"net/http"
	"path/filepath"
	"github.com/gin-contrib/multitemplate"
	"time"
)

func loadTemplates(templatesDir string) multitemplate.Renderer {
	r := multitemplate.NewRenderer()
	layouts, err := filepath.Glob(templatesDir + "/layouts/*.html")
	if err != nil {
		panic(err.Error())
	}
	includes, err := filepath.Glob(templatesDir + "/includes/*.html")
	if err != nil {
		panic(err.Error())
	}
	// 为layouts/和includes/目录生成 templates map
	for _, include := range includes {
		layoutCopy := make([]string, len(layouts))
		copy(layoutCopy, layouts)
		files := append(layoutCopy, include)
		r.AddFromFiles(filepath.Base(include), files...)
	}
	return r
}

func main() {
	//router := gin.Default()  // -> 创建了一个带Logger()和Recovery()两个中间件的router
	router := gin.New()  // -> 创建了一个不带默认中间件的router
	//router.Use(Logger())  // -> 全局注册中间件
	// 先添加自定义的模板函数
	router.SetFuncMap(template.FuncMap{
		"safe": func(str string) template.HTML{
			return template.HTML(str)
		},
	})
	router.StaticFS("/showDir", http.Dir("."))
	// router.Static("/static", "./static")
	router.Static("/oo", "./images")
	//加载模板
	//router.LoadHTMLGlob("templates/**/*")
	router.HTMLRender = loadTemplates("templates")
	//router.LoadHTMLFiles("templates/template1.html", "templates/template2.html")
	//定义路由
	//router.GET("/shop/index", func(c *gin.Context) {
	//	//根据完整文件名渲染模板，并传递参数
	//	c.HTML(http.StatusOK, "xx.tmpl", gin.H{
	//		"title": "shop/index ",
	//	})
	//})
	//router.GET("/post/index", func(c *gin.Context) {
	//	//根据完整文件名渲染模板，并传递参数
	//	c.HTML(http.StatusOK, "index.tmpl", gin.H{
	//		"title": "post/index ",
	//	})
	//})
	//// safe
	//router.GET("/safe", func(c *gin.Context) {
	//	//根据完整文件名渲染模板，并传递参数
	//	c.HTML(http.StatusOK, "safe.html", gin.H{
	//		"content": "<a href='https://www.lianshiclass.com'>lianshi</a>",
	//	})
	//})

	// 模板继承
	router.GET("/base/index", func(c *gin.Context) {
		// 统计耗时
		c.HTML(http.StatusOK, "index.html", gin.H{

			"content": "/base/index",
		})
	})
	router.GET("/base/home", func(c *gin.Context) {
		// 统计耗时
		c.HTML(http.StatusOK, "home.html", gin.H{
			"content": "/base/home",
		})
	})
	// 重定向 请求来了之后我告诉它去访问别的地址
	router.GET("/redirect", func(c *gin.Context) {
		// 统计耗时
		//支持内部和外部的重定向
		c.Redirect(http.StatusMovedPermanently, "http://www.baidu.com/")
		//c.Redirect(http.StatusMovedPermanently, "/base/home")
	})

	// 中间件
	adminGroup := router.Group("/admin")
	{
		adminGroup.GET("/index", MiddlewareFunc1, func(c *gin.Context) {
			// 统计耗时

		})
		adminGroup.GET("/home", MiddlewareFunc2(false), func(c *gin.Context) {
			// 登录的校验
			// 统计耗时
		})
	}

	router.Run(":8080")
}

// 中间件
func MiddlewareFunc1(c *gin.Context){
	t := time.Now()
	fmt.Println("before middleware")
	//设置request变量到Context的Key中,通过Get等函数可以取得
	c.Set("request", "client_request")
	//发送request之前
	c.Next()  // --> 去执行下一个处理函数
	//发送requst之后
	// 这个c.Write是ResponseWriter,我们可以获得状态等信息
	status := c.Writer.Status()
	fmt.Println("after middleware,", status)
	t2 := time.Since(t)
	fmt.Println("time:", t2)
}

func MiddlewareFunc2(debug bool) gin.HandlerFunc {
	return func(c *gin.Context) {
		if debug{

		}else {

		}
		t := time.Now()
		fmt.Println("before middleware")
		//设置request变量到Context的Key中,通过Get等函数可以取得
		c.Set("request", "client_request")
		//发送request之前
		c.Next()
		//发送requst之后
		// 这个c.Write是ResponseWriter,我们可以获得状态等信息
		status := c.Writer.Status()
		fmt.Println("after middleware,", status)
		t2 := time.Since(t)
		fmt.Println("time:", t2)
	}
}