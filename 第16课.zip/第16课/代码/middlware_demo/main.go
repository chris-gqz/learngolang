package main

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
)

func indexFunc(c *gin.Context){
	fmt.Println("index")
	v, ok := c.Get("name")
	if ok {
		fmt.Println(v)
	}
	c.String(http.StatusOK, "index")
}
func Middleware1() gin.HandlerFunc{
	return func(c *gin.Context) {
		fmt.Println("m1 before")
		c.Set("name", "小P")
		c.Next()
		fmt.Println("m1 after")
	}
}

func Middleware2() gin.HandlerFunc{
	return func(c *gin.Context) {
		fmt.Println("m2 before")
		//c.Next()
		c.Abort() // 终止函数直接返回响应
		// 业务处理函数已经写入了响应了
		fmt.Println("m2 after")
	}
}
func main() {
	r := gin.Default()
	//r.Use(Middleware1(), Middleware2())  // 全局注册
	//r.Group("/shop", Middleware1(), Middleware2())  // 路由组注册中间件
	r.GET("/index", Middleware1(), Middleware2(), indexFunc)  // 指定某个路由注册中间件
	//r.GET("/index", Middleware1(), indexFunc,  Middleware2())  // 指定某个路由注册中间件

	r.Run()
}
